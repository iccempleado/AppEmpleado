 $( document ).ready(function() {
	 
	var Load_user = localStorage.getItem('username') || 'empty';
	var Load_pass = localStorage.getItem('passw') || 'empty';
	
	if (Load_user == 'empty'){
		$('#inputEmail').val('');
		$('#inputPassword').val('');
	}else{
		$('#inputEmail').val(Load_user);
		$('#inputPassword').val(Load_pass);
	}
    
	$("#login-button").click(function(event){
		event.preventDefault();
		var username = $('#inputEmail').val();
		var passw = $('#inputPassword').val();
		if (passw != '' && username != ''){
			$.ajax({ 
				type: 'POST', 
				url: 'http://190.24.138.149/APP_ICC_CONTROL/log_user.php',
				data: {
					"ICCUser" : username,
					"ICCPass" : passw
				},
				success: function (data) { 
					if (data == 'USER NOT FOUND'){
						alert(data);
					}else{
						localStorage.setItem("username", username);
						localStorage.setItem("passw", passw);
						setTimeout("redireccionarPagina("+data+")", 2000);
					}
				}
			});
			
		}else{
			alert("Campos Null");
		}
	});
	$('#clearUser').on('click', function() {
		localStorage.clear();
		$('#inputEmail').val('');
		$('#inputPassword').val('');
   });
 });
function redireccionarPagina(docum1) {
	var user1=document.getElementById("inputEmail").value;
	var pass1=document.getElementById("inputPassword").value;
	$('form').fadeOut(300);
	$('.wrapper').addClass('form-success');
	window.location = "controlICC.html?user="+user1+"&pass="+pass1+"&docum="+docum1;
}
